package com.practice.Flower_catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowerCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
