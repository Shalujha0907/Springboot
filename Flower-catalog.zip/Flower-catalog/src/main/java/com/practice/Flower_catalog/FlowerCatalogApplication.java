package com.practice.Flower_catalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlowerCatalogApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlowerCatalogApplication.class, args);
	}

}
